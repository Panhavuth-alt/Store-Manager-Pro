using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace PremiumStoreUI
{
    public class CustomerManagementUI
    {
        private Panel panel;
        private DataGridView dgv;
        private TextBox searchBox;

        public CustomerManagementUI(Panel contentPanel)
        {
            this.panel = contentPanel;
        }

        public void Initialize()
        {
            panel.Controls.Clear();

            // Title
            Label title = new Label
            {
                Text = "👥 Customer Management",
                Location = new Point(0, 10),
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true
            };
            panel.Controls.Add(title);

            // Search Box
            searchBox = new TextBox
            {
                Location = new Point(0, 70),
                Width = 300,
                Height = 35,
                Font = new Font("Segoe UI", 12),
                BackColor = Color.FromArgb(35, 35, 40),
                ForeColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            searchBox.Text = "🔍 Search customers...";
            searchBox.ForeColor = Color.Gray;

            searchBox.GotFocus += (s, e) =>
            {
                if (searchBox.Text == "🔍 Search customers...")
                {
                    searchBox.Text = "";
                    searchBox.ForeColor = Color.White;
                }
            };

            searchBox.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(searchBox.Text))
                {
                    searchBox.Text = "🔍 Search customers...";
                    searchBox.ForeColor = Color.Gray;
                }
            };

            panel.Controls.Add(searchBox);

            // Buttons
            Button addBtn = CreateActionButton("➕ Add Customer", new Point(320, 70));
            Button editBtn = CreateActionButton("✏️ Edit", new Point(480, 70));
            Button deleteBtn = CreateActionButton("🗑️ Delete", new Point(600, 70));
            Button exportBtn = CreateActionButton("📊 Export", new Point(720, 70));

            panel.Controls.AddRange(new Control[] { addBtn, editBtn, deleteBtn, exportBtn });

            // DataGridView
            dgv = new DataGridView
            {
                Location = new Point(0, 130),
                Size = new Size(980, 520),
                BackgroundColor = Color.FromArgb(25, 25, 30),
                BorderStyle = BorderStyle.None,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(35, 35, 40),
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 11, FontStyle.Bold),
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                    Padding = new Padding(8, 5, 8, 5)
                },
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(25, 25, 30),
                    ForeColor = Color.White,
                    SelectionBackColor = Color.FromArgb(60, 70, 130),
                    SelectionForeColor = Color.White,
                    Font = new Font("Segoe UI", 10),
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                    Padding = new Padding(8, 0, 8, 0)
                },
                EnableHeadersVisualStyles = false,
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ColumnHeadersHeight = 40
            };

            dgv.RowTemplate.Height = 35;
            LoadCustomers();
            panel.Controls.Add(dgv);

            // Event Handlers
            searchBox.TextChanged += (s, e) =>
            {
                if (searchBox.Text != "🔍 Search customers..." && !string.IsNullOrWhiteSpace(searchBox.Text))
                {
                    var filtered = DatabaseManager.Instance.SearchCustomers(searchBox.Text);
                    dgv.DataSource = filtered;
                }
                else
                {
                    LoadCustomers();
                }
            };

            addBtn.Click += (s, e) => { ShowCustomerDialog(); LoadCustomers(); };
            editBtn.Click += (s, e) =>
            {
                if (dgv.SelectedRows.Count > 0)
                {
                    int id = Convert.ToInt32(dgv.SelectedRows[0].Cells["Id"].Value);
                    ShowCustomerDialog(id);
                    LoadCustomers();
                }
            };
            deleteBtn.Click += (s, e) =>
            {
                if (dgv.SelectedRows.Count > 0)
                {
                    int id = Convert.ToInt32(dgv.SelectedRows[0].Cells["Id"].Value);
                    if (MessageBox.Show("Delete this customer?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        DatabaseManager.Instance.DeleteCustomer(id);
                        LoadCustomers();
                    }
                }
            };
            exportBtn.Click += (s, e) =>
            {
                ExportHelper.ExportToCSV(dgv.DataSource as DataTable, "Customers_Export.csv");
            };
        }

        private void LoadCustomers()
        {
            dgv.DataSource = DatabaseManager.Instance.GetAllCustomers();
        }

        private Button CreateActionButton(string text, Point location)
        {
            Button btn = new Button
            {
                Text = text,
                Location = location,
                Width = 150,
                Height = 35,
                BackColor = Color.FromArgb(60, 70, 130),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10),
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            return btn;
        }

        private void ShowCustomerDialog(int? customerId = null)
        {
            Form dialog = new Form
            {
                Size = new Size(500, 550),
                BackColor = Color.FromArgb(25, 25, 30),
                FormBorderStyle = FormBorderStyle.FixedDialog,
                StartPosition = FormStartPosition.CenterParent,
                Text = customerId.HasValue ? "Edit Customer" : "Add Customer",
                MaximizeBox = false,
                MinimizeBox = false
            };

            Label[] labels = {
                new Label { Text = "Name:", Location = new Point(30, 30), ForeColor = Color.White, AutoSize = true },
                new Label { Text = "Phone:", Location = new Point(30, 100), ForeColor = Color.White, AutoSize = true },
                new Label { Text = "Email:", Location = new Point(30, 170), ForeColor = Color.White, AutoSize = true },
                new Label { Text = "Address:", Location = new Point(30, 240), ForeColor = Color.White, AutoSize = true },
                new Label { Text = "Loyalty Points:", Location = new Point(30, 310), ForeColor = Color.White, AutoSize = true }
            };

            TextBox nameBox = new TextBox { Location = new Point(30, 60), Width = 420, BackColor = Color.FromArgb(35, 35, 40), ForeColor = Color.White, Font = new Font("Segoe UI", 11) };
            TextBox phoneBox = new TextBox { Location = new Point(30, 130), Width = 420, BackColor = Color.FromArgb(35, 35, 40), ForeColor = Color.White, Font = new Font("Segoe UI", 11) };
            TextBox emailBox = new TextBox { Location = new Point(30, 200), Width = 420, BackColor = Color.FromArgb(35, 35, 40), ForeColor = Color.White, Font = new Font("Segoe UI", 11) };
            TextBox addressBox = new TextBox { Location = new Point(30, 270), Width = 420, BackColor = Color.FromArgb(35, 35, 40), ForeColor = Color.White, Font = new Font("Segoe UI", 11) };
            NumericUpDown pointsBox = new NumericUpDown { Location = new Point(30, 340), Width = 420, BackColor = Color.FromArgb(35, 35, 40), ForeColor = Color.White, Font = new Font("Segoe UI", 11), Minimum = 0, Maximum = 999999 };

            if (customerId.HasValue)
            {
                var customer = DatabaseManager.Instance.GetCustomerById(customerId.Value);
                if (customer != null)
                {
                    nameBox.Text = customer.Name;
                    phoneBox.Text = customer.Phone;
                    emailBox.Text = customer.Email;
                    addressBox.Text = customer.Address;
                    pointsBox.Value = customer.LoyaltyPoints;
                }
            }

            Button saveBtn = new Button
            {
                Text = "💾 Save",
                Location = new Point(150, 450),
                Width = 200,
                Height = 40,
                BackColor = Color.FromArgb(60, 140, 100),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 12)
            };
            saveBtn.FlatAppearance.BorderSize = 0;

            saveBtn.Click += (s, e) =>
            {
                // Validation
                if (!ValidationHelper.ValidateRequired(nameBox.Text))
                {
                    MessageBox.Show("Name is required!", "Validation Error");
                    return;
                }

                if (!ValidationHelper.ValidatePhone(phoneBox.Text))
                {
                    MessageBox.Show("Invalid phone number!", "Validation Error");
                    return;
                }

                if (!string.IsNullOrWhiteSpace(emailBox.Text) && !ValidationHelper.ValidateEmail(emailBox.Text))
                {
                    MessageBox.Show("Invalid email address!", "Validation Error");
                    return;
                }

                if (customerId.HasValue)
                {
                    DatabaseManager.Instance.UpdateCustomer(
                        customerId.Value,
                        nameBox.Text,
                        phoneBox.Text,
                        emailBox.Text,
                        addressBox.Text,
                        (int)pointsBox.Value
                    );
                }
                else
                {
                    DatabaseManager.Instance.AddCustomer(
                        nameBox.Text,
                        phoneBox.Text,
                        emailBox.Text,
                        addressBox.Text,
                        (int)pointsBox.Value
                    );
                }

                dialog.Close();
            };

            dialog.Controls.AddRange(labels);
            dialog.Controls.AddRange(new Control[] { nameBox, phoneBox, emailBox, addressBox, pointsBox, saveBtn });
            dialog.ShowDialog();
        }
    }
}
