using System;
using System.Data;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace PremiumStoreUI
{
    // Design Pattern #8: Facade Pattern (simplify export operations)
    public static class ExportHelper
    {
        /// <summary>
        /// Export DataTable to CSV (Excel-compatible)
        /// </summary>
        public static void ExportToCSV(DataTable dataTable, string fileName)
        {
            try
            {
                SaveFileDialog saveDialog = new SaveFileDialog
                {
                    Filter = "CSV files (*.csv)|*.csv",
                    FileName = fileName,
                    DefaultExt = "csv"
                };

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    StringBuilder sb = new StringBuilder();

                    // Headers
                    string[] columnNames = new string[dataTable.Columns.Count];
                    for (int i = 0; i < dataTable.Columns.Count; i++)
                    {
                        columnNames[i] = dataTable.Columns[i].ColumnName;
                    }
                    sb.AppendLine(string.Join(",", columnNames));

                    // Data
                    foreach (DataRow row in dataTable.Rows)
                    {
                        string[] fields = new string[dataTable.Columns.Count];
                        for (int i = 0; i < dataTable.Columns.Count; i++)
                        {
                            fields[i] = EscapeCSV(row[i].ToString());
                        }
                        sb.AppendLine(string.Join(",", fields));
                    }

                    File.WriteAllText(saveDialog.FileName, sb.ToString(), Encoding.UTF8);
                    
                    MessageBox.Show($"✅ Exported successfully to:\n{saveDialog.FileName}", 
                        "Export Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    // Open file
                    System.Diagnostics.Process.Start("explorer.exe", $"/select, \"{saveDialog.FileName}\"");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Export failed:\n{ex.Message}", 
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Export DataTable to HTML (printable)
        /// </summary>
        public static void ExportToHTML(DataTable dataTable, string fileName, string title)
        {
            try
            {
                SaveFileDialog saveDialog = new SaveFileDialog
                {
                    Filter = "HTML files (*.html)|*.html",
                    FileName = fileName,
                    DefaultExt = "html"
                };

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    StringBuilder html = new StringBuilder();
                    
                    html.AppendLine("<!DOCTYPE html>");
                    html.AppendLine("<html>");
                    html.AppendLine("<head>");
                    html.AppendLine("<meta charset='utf-8'>");
                    html.AppendLine($"<title>{title}</title>");
                    html.AppendLine("<style>");
                    html.AppendLine("body { font-family: 'Segoe UI', Arial, sans-serif; margin: 40px; background: #f5f5f5; }");
                    html.AppendLine(".header { text-align: center; margin-bottom: 30px; }");
                    html.AppendLine(".header h1 { color: #2c3e50; margin: 0; }");
                    html.AppendLine(".header p { color: #7f8c8d; margin: 5px 0; }");
                    html.AppendLine("table { width: 100%; border-collapse: collapse; background: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }");
                    html.AppendLine("th { background: #34495e; color: white; padding: 12px; text-align: left; font-weight: 600; }");
                    html.AppendLine("td { padding: 10px; border-bottom: 1px solid #ecf0f1; }");
                    html.AppendLine("tr:hover { background: #f8f9fa; }");
                    html.AppendLine(".footer { text-align: center; margin-top: 30px; color: #7f8c8d; font-size: 12px; }");
                    html.AppendLine("@media print { body { margin: 0; } }");
                    html.AppendLine("</style>");
                    html.AppendLine("</head>");
                    html.AppendLine("<body>");
                    
                    html.AppendLine("<div class='header'>");
                    html.AppendLine("<h1>🏪 Store Manager Pro</h1>");
                    html.AppendLine($"<h2>{title}</h2>");
                    html.AppendLine($"<p>Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}</p>");
                    html.AppendLine("</div>");
                    
                    html.AppendLine("<table>");
                    html.AppendLine("<thead><tr>");
                    
                    // Headers
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        html.AppendLine($"<th>{column.ColumnName}</th>");
                    }
                    html.AppendLine("</tr></thead>");
                    
                    // Data
                    html.AppendLine("<tbody>");
                    foreach (DataRow row in dataTable.Rows)
                    {
                        html.AppendLine("<tr>");
                        foreach (var item in row.ItemArray)
                        {
                            html.AppendLine($"<td>{item}</td>");
                        }
                        html.AppendLine("</tr>");
                    }
                    html.AppendLine("</tbody>");
                    html.AppendLine("</table>");
                    
                    html.AppendLine("<div class='footer'>");
                    html.AppendLine($"<p>Total Records: {dataTable.Rows.Count}</p>");
                    html.AppendLine("<p>© Store Manager Pro - Premium Store Management System</p>");
                    html.AppendLine("</div>");
                    
                    html.AppendLine("</body>");
                    html.AppendLine("</html>");

                    File.WriteAllText(saveDialog.FileName, html.ToString(), Encoding.UTF8);
                    
                    MessageBox.Show($"✅ Exported successfully to:\n{saveDialog.FileName}", 
                        "Export Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    // Open in browser
                    System.Diagnostics.Process.Start(saveDialog.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Export failed:\n{ex.Message}", 
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Print receipt
        /// </summary>
        public static string GenerateReceipt(int saleId, decimal totalAmount, string paymentMethod)
        {
            StringBuilder receipt = new StringBuilder();
            
            receipt.AppendLine("╔════════════════════════════════════╗");
            receipt.AppendLine("║    🏪 STORE MANAGER PRO           ║");
            receipt.AppendLine("║    Premium Store Management        ║");
            receipt.AppendLine("╚════════════════════════════════════╝");
            receipt.AppendLine();
            receipt.AppendLine($"Receipt #: {saleId}");
            receipt.AppendLine($"Date: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            receipt.AppendLine($"Cashier: {CurrentUser.Instance.GetUser()?.FullName ?? "Unknown"}");
            receipt.AppendLine();
            receipt.AppendLine("────────────────────────────────────");
            receipt.AppendLine();
            
            // Get sale details would go here
            receipt.AppendLine("Items purchased:");
            // Add items...
            
            receipt.AppendLine();
            receipt.AppendLine("────────────────────────────────────");
            receipt.AppendLine($"TOTAL:          ${totalAmount:F2}");
            receipt.AppendLine($"Payment Method: {paymentMethod}");
            receipt.AppendLine("────────────────────────────────────");
            receipt.AppendLine();
            receipt.AppendLine("    Thank you for your purchase!");
            receipt.AppendLine("         Please come again!");
            receipt.AppendLine();
            receipt.AppendLine("════════════════════════════════════");
            
            return receipt.ToString();
        }

        /// <summary>
        /// Import products from CSV
        /// </summary>
        public static int ImportFromCSV()
        {
            try
            {
                OpenFileDialog openDialog = new OpenFileDialog
                {
                    Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*",
                    Title = "Import Products from CSV"
                };

                if (openDialog.ShowDialog() == DialogResult.OK)
                {
                    string[] lines = File.ReadAllLines(openDialog.FileName);
                    int imported = 0;

                    // Skip header row
                    for (int i = 1; i < lines.Length; i++)
                    {
                        string[] fields = lines[i].Split(',');
                        
                        if (fields.Length >= 4)
                        {
                            try
                            {
                                string name = fields[0].Trim().Trim('"');
                                decimal price = decimal.Parse(fields[1].Trim());
                                int stock = int.Parse(fields[2].Trim());
                                string category = fields[3].Trim().Trim('"');

                                if (ValidationHelper.ValidatePrice(price) && ValidationHelper.ValidateStock(stock))
                                {
                                    DatabaseManager.Instance.AddProduct(name, price, stock, category);
                                    imported++;
                                }
                            }
                            catch
                            {
                                // Skip invalid rows
                                continue;
                            }
                        }
                    }

                    MessageBox.Show($"✅ Imported {imported} products successfully!", 
                        "Import Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    return imported;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Import failed:\n{ex.Message}", 
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            return 0;
        }

        private static string EscapeCSV(string value)
        {
            if (value.Contains(",") || value.Contains("\"") || value.Contains("\n"))
            {
                return "\"" + value.Replace("\"", "\"\"") + "\"";
            }
            return value;
        }

        /// <summary>
        /// Backup database
        /// </summary>
        public static void BackupDatabase()
        {
            try
            {
                SaveFileDialog saveDialog = new SaveFileDialog
                {
                    Filter = "Database Backup (*.db)|*.db",
                    FileName = $"store_backup_{DateTime.Now:yyyyMMdd_HHmmss}.db",
                    DefaultExt = "db"
                };

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    File.Copy("store.db", saveDialog.FileName, true);
                    
                    MessageBox.Show($"✅ Database backed up successfully to:\n{saveDialog.FileName}", 
                        "Backup Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    System.Diagnostics.Process.Start("explorer.exe", $"/select, \"{saveDialog.FileName}\"");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Backup failed:\n{ex.Message}", 
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
