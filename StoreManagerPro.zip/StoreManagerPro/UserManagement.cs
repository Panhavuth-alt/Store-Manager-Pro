using System;
using System.Security.Cryptography;
using System.Text;

namespace PremiumStoreUI
{
    // Design Pattern #6: Singleton Pattern (for current user session)
    public class CurrentUser
    {
        private static CurrentUser instance;
        private User currentUser;

        public static CurrentUser Instance
        {
            get
            {
                if (instance == null)
                    instance = new CurrentUser();
                return instance;
            }
        }

        private CurrentUser() { }

        public void SetUser(User user)
        {
            currentUser = user;
        }

        public User GetUser()
        {
            return currentUser;
        }

        public bool IsLoggedIn()
        {
            return currentUser != null;
        }

        public void Logout()
        {
            currentUser = null;
        }
    }

    // User Model
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
        public string Role { get; set; } // Admin, Manager, Cashier
        public DateTime CreatedDate { get; set; }
        public bool IsActive { get; set; }

        // Design Pattern #7: Decorator Pattern (for permissions)
        public bool CanAddProduct()
        {
            return Role == "Admin" || Role == "Manager";
        }

        public bool CanDeleteProduct()
        {
            return Role == "Admin";
        }

        public bool CanViewReports()
        {
            return true; // All users can view reports
        }

        public bool CanManageUsers()
        {
            return Role == "Admin";
        }

        public bool CanManageCustomers()
        {
            return Role == "Admin" || Role == "Manager";
        }
    }

    // Customer Model
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public int LoyaltyPoints { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? LastPurchase { get; set; }
    }

    // Security Helper
    public static class SecurityHelper
    {
        public static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        public static bool VerifyPassword(string password, string hash)
        {
            string hashOfInput = HashPassword(password);
            return hashOfInput.Equals(hash, StringComparison.OrdinalIgnoreCase);
        }
    }

    // Validation Helper
    public static class ValidationHelper
    {
        public static bool ValidatePrice(decimal price)
        {
            return price > 0;
        }

        public static bool ValidateStock(int stock)
        {
            return stock >= 0;
        }

        public static bool ValidateEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;
            
            return email.Contains("@") && email.Contains(".");
        }

        public static bool ValidatePhone(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone))
                return false;
            
            // Remove spaces and dashes
            phone = phone.Replace(" ", "").Replace("-", "");
            
            return phone.Length >= 9 && phone.All(char.IsDigit);
        }

        public static bool ValidateRequired(string value)
        {
            return !string.IsNullOrWhiteSpace(value);
        }
    }
}
