using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace PremiumStoreUI
{
    public class GlowCard : Panel
    {
        public Color GlowColor { get; set; } = Color.FromArgb(45, 50, 120);
        public string TitleText { get; set; } = "Title";
        public string ValueText { get; set; } = "$0.00";

        public GlowCard()
        {
            this.DoubleBuffered = true;
            this.Size = new Size(220, 155);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            
            using (LinearGradientBrush b = new LinearGradientBrush(
                this.ClientRectangle, 
                GlowColor, 
                Color.FromArgb(20, 20, 35), 
                45f))
            {
                GraphicsPath path = new GraphicsPath();
                int d = 20;
                path.AddArc(0, 0, d, d, 180, 90);
                path.AddArc(Width - d, 0, d, d, 270, 90);
                path.AddArc(Width - d, Height - d, d, d, 0, 90);
                path.AddArc(0, Height - d, d, d, 90, 90);
                path.CloseFigure();
                e.Graphics.FillPath(b, path);
            }
            
            e.Graphics.DrawString(TitleText, new Font("Segoe UI", 11), Brushes.Silver, 20, 20);
            e.Graphics.DrawString(ValueText, new Font("Segoe UI", 24, FontStyle.Bold), Brushes.White, 20, 60);
        }
    }

    // Factory Pattern - Design Pattern #2
    public class CardFactory
    {
        public GlowCard CreateCard(string title, string value, Color glowColor, Point location)
        {
            return new GlowCard
            {
                TitleText = title,
                ValueText = value,
                GlowColor = glowColor,
                Location = location
            };
        }
    }
}
