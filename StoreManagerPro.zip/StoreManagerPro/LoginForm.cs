using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace PremiumStoreUI
{
    public class LoginForm : Form
    {
        private TextBox usernameBox;
        private TextBox passwordBox;
        private Button loginButton;
        private Label errorLabel;

        public LoginForm()
        {
            InitializeUI();
        }

        private void InitializeUI()
        {
            this.Size = new Size(500, 600);
            this.BackColor = Color.FromArgb(15, 15, 18);
            this.Text = "Store Manager Pro - Login";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // Logo/Title
            Label titleLabel = new Label
            {
                Text = "🏪 Store Manager Pro",
                Location = new Point(50, 80),
                Size = new Size(400, 60),
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleCenter
            };

            Label subtitleLabel = new Label
            {
                Text = "Please login to continue",
                Location = new Point(50, 150),
                Size = new Size(400, 30),
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.Gray,
                TextAlign = ContentAlignment.MiddleCenter
            };

            // Username
            Label usernameLabel = new Label
            {
                Text = "Username:",
                Location = new Point(50, 220),
                Size = new Size(150, 25),
                Font = new Font("Segoe UI", 11),
                ForeColor = Color.White
            };

            usernameBox = new TextBox
            {
                Location = new Point(50, 250),
                Size = new Size(400, 40),
                Font = new Font("Segoe UI", 12),
                BackColor = Color.FromArgb(35, 35, 40),
                ForeColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            // Password
            Label passwordLabel = new Label
            {
                Text = "Password:",
                Location = new Point(50, 310),
                Size = new Size(150, 25),
                Font = new Font("Segoe UI", 11),
                ForeColor = Color.White
            };

            passwordBox = new TextBox
            {
                Location = new Point(50, 340),
                Size = new Size(400, 40),
                Font = new Font("Segoe UI", 12),
                BackColor = Color.FromArgb(35, 35, 40),
                ForeColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                UseSystemPasswordChar = true
            };

            // Error Label
            errorLabel = new Label
            {
                Location = new Point(50, 390),
                Size = new Size(400, 25),
                Font = new Font("Segoe UI", 10),
                ForeColor = Color.FromArgb(255, 100, 100),
                TextAlign = ContentAlignment.MiddleCenter,
                Visible = false
            };

            // Login Button
            loginButton = new Button
            {
                Text = "🔐 Login",
                Location = new Point(50, 430),
                Size = new Size(400, 50),
                BackColor = Color.FromArgb(60, 120, 100),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            loginButton.FlatAppearance.BorderSize = 0;
            loginButton.Click += LoginButton_Click;

            // Default credentials hint
            Label hintLabel = new Label
            {
                Text = "💡 Default: admin / admin123",
                Location = new Point(50, 500),
                Size = new Size(400, 25),
                Font = new Font("Segoe UI", 9, FontStyle.Italic),
                ForeColor = Color.Gray,
                TextAlign = ContentAlignment.MiddleCenter
            };

            // Add Enter key support
            passwordBox.KeyPress += (s, e) =>
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    LoginButton_Click(null, null);
                }
            };

            this.Controls.AddRange(new Control[] {
                titleLabel, subtitleLabel,
                usernameLabel, usernameBox,
                passwordLabel, passwordBox,
                errorLabel, loginButton, hintLabel
            });
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            errorLabel.Visible = false;

            // Validation
            if (string.IsNullOrWhiteSpace(usernameBox.Text))
            {
                ShowError("Please enter username!");
                return;
            }

            if (string.IsNullOrWhiteSpace(passwordBox.Text))
            {
                ShowError("Please enter password!");
                return;
            }

            // Authenticate
            var user = DatabaseManager.Instance.AuthenticateUser(
                usernameBox.Text.Trim(),
                passwordBox.Text
            );

            if (user != null)
            {
                // Set current user
                CurrentUser.Instance.SetUser(user);

                // Log activity
                DatabaseManager.Instance.LogActivity(user.Id, "Login", "User logged in");

                // Show main form
                this.Hide();
                MainForm.Instance.Show();
                // MainForm will automatically adjust based on current user
            }
            else
            {
                ShowError("Invalid username or password!");
                passwordBox.Clear();
                passwordBox.Focus();
            }
        }

        private void ShowError(string message)
        {
            errorLabel.Text = message;
            errorLabel.Visible = true;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!CurrentUser.Instance.IsLoggedIn())
            {
                Application.Exit();
            }
            base.OnFormClosing(e);
        }
    }
}
