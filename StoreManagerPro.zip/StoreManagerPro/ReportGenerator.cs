using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace PremiumStoreUI
{
    // Command Pattern - Design Pattern #5
    public interface IReportCommand
    {
        void Execute(Panel panel, Point location);
        string GetReportName();
    }

    public class SalesReportCommand : IReportCommand
    {
        public string GetReportName() => "Sales Report";

        public void Execute(Panel panel, Point location)
        {
            DataGridView dgv = new DataGridView
            {
                Location = location,
                Size = new Size(950, 300),
                BackgroundColor = Color.FromArgb(25, 25, 30),
                BorderStyle = BorderStyle.None,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(35, 35, 40),
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 10, FontStyle.Bold),
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                    Padding = new Padding(8, 5, 8, 5)
                },
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(25, 25, 30),
                    ForeColor = Color.White,
                    SelectionBackColor = Color.FromArgb(60, 70, 130),
                    SelectionForeColor = Color.White,
                    Font = new Font("Segoe UI", 9),
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                    Padding = new Padding(8, 0, 8, 0)
                },
                EnableHeadersVisualStyles = false,
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ColumnHeadersHeight = 38
            };

            dgv.RowTemplate.Height = 32;
            dgv.DataSource = DatabaseManager.Instance.GetSalesReport();
            panel.Controls.Add(dgv);
        }
    }

    public class StockReportCommand : IReportCommand
    {
        public string GetReportName() => "Stock Report";

        public void Execute(Panel panel, Point location)
        {
            Chart chart = new Chart
            {
                Location = location,
                Size = new Size(950, 300),
                BackColor = Color.FromArgb(25, 25, 30)
            };

            ChartArea chartArea = new ChartArea
            {
                BackColor = Color.FromArgb(25, 25, 30)
            };
            chartArea.AxisX.MajorGrid.LineColor = Color.FromArgb(40, 40, 45);
            chartArea.AxisY.MajorGrid.LineColor = Color.FromArgb(40, 40, 45);
            chartArea.AxisX.LabelStyle.ForeColor = Color.Gray;
            chartArea.AxisY.LabelStyle.ForeColor = Color.Gray;
            chart.ChartAreas.Add(chartArea);

            Series series = new Series
            {
                ChartType = SeriesChartType.Bar,
                Color = Color.FromArgb(100, 150, 255)
            };

            var products = DatabaseManager.Instance.GetAllProducts();
            foreach (DataRow row in products.Rows)
            {
                series.Points.AddXY(row["Name"].ToString(), Convert.ToInt32(row["Stock"]));
            }

            chart.Series.Add(series);
            panel.Controls.Add(chart);
        }
    }

    public class RevenueReportCommand : IReportCommand
    {
        public string GetReportName() => "Revenue Analysis";

        public void Execute(Panel panel, Point location)
        {
            Chart chart = new Chart
            {
                Location = location,
                Size = new Size(950, 300),
                BackColor = Color.FromArgb(25, 25, 30)
            };

            ChartArea chartArea = new ChartArea
            {
                BackColor = Color.FromArgb(25, 25, 30)
            };
            chartArea.AxisX.MajorGrid.LineColor = Color.FromArgb(40, 40, 45);
            chartArea.AxisY.MajorGrid.LineColor = Color.FromArgb(40, 40, 45);
            chartArea.AxisX.LabelStyle.ForeColor = Color.Gray;
            chartArea.AxisY.LabelStyle.ForeColor = Color.Gray;
            chart.ChartAreas.Add(chartArea);

            Series series = new Series
            {
                ChartType = SeriesChartType.Pie,
                Font = new Font("Segoe UI", 10)
            };

            var products = DatabaseManager.Instance.GetAllProducts();
            foreach (DataRow row in products.Rows)
            {
                decimal revenue = Convert.ToDecimal(row["Price"]) * Convert.ToInt32(row["Stock"]);
                var point = series.Points.Add((double)revenue);
                // Removed label on pie chart - only show in legend
                point.LegendText = $"{row["Name"]} (${revenue:F2})";
            }

            chart.Series.Add(series);

            Legend legend = new Legend
            {
                Docking = Docking.Right,
                ForeColor = Color.White,
                BackColor = Color.Transparent
            };
            chart.Legends.Add(legend);

            panel.Controls.Add(chart);
        }
    }

    public class ReportGenerator
    {
        private Panel panel;
        private IReportCommand currentReport;
        private Point reportLocation = new Point(0, 150);

        public ReportGenerator(Panel contentPanel)
        {
            this.panel = contentPanel;
        }

        public void GenerateReports()
        {
            Label lblSelect = new Label
            {
                Text = "Select Report Type:",
                Location = new Point(0, 70),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12),
                AutoSize = true
            };
            panel.Controls.Add(lblSelect);

            Button salesBtn = CreateReportButton("📊 Sales Report", new Point(0, 100), new SalesReportCommand());
            Button stockBtn = CreateReportButton("📦 Stock Report", new Point(180, 100), new StockReportCommand());
            Button revenueBtn = CreateReportButton("💰 Revenue Analysis", new Point(360, 100), new RevenueReportCommand());

            panel.Controls.AddRange(new Control[] { salesBtn, stockBtn, revenueBtn });

            // Generate default report
            currentReport = new SalesReportCommand();
            ExecuteReport();
        }

        private Button CreateReportButton(string text, Point location, IReportCommand command)
        {
            Button btn = new Button
            {
                Text = text,
                Location = location,
                Width = 160,
                Height = 40,
                BackColor = Color.FromArgb(60, 70, 130),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10)
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += (s, e) =>
            {
                currentReport = command;
                ExecuteReport();
            };
            return btn;
        }

        private void ExecuteReport()
        {
            // Clear previous report
            var controlsToRemove = new List<Control>();
            foreach (Control c in panel.Controls)
            {
                if (c.Location.Y >= reportLocation.Y)
                    controlsToRemove.Add(c);
            }
            foreach (var c in controlsToRemove)
                panel.Controls.Remove(c);

            // Execute new report
            if (currentReport != null)
                currentReport.Execute(panel, reportLocation);
        }
    }
}
