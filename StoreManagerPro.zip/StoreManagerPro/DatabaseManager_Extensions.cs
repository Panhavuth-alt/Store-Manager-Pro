using System;
using System.Data;
using System.Data.SQLite;

namespace PremiumStoreUI
{
    // Extensions to DatabaseManager for new features
    public partial class DatabaseManager
    {
        // ========== USER MANAGEMENT ==========
        
        public void InitializeUsersTable()
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                
                string createUsers = @"CREATE TABLE IF NOT EXISTS Users (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Username TEXT UNIQUE NOT NULL,
                    PasswordHash TEXT NOT NULL,
                    FullName TEXT NOT NULL,
                    Role TEXT NOT NULL,
                    CreatedDate DATETIME DEFAULT CURRENT_TIMESTAMP,
                    IsActive INTEGER DEFAULT 1
                )";
                
                using (var cmd = new SQLiteCommand(createUsers, conn))
                    cmd.ExecuteNonQuery();
                
                // Create default admin user if not exists
                string checkAdmin = "SELECT COUNT(*) FROM Users WHERE Username = 'admin'";
                using (var cmd = new SQLiteCommand(checkAdmin, conn))
                {
                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    if (count == 0)
                    {
                        string insertAdmin = @"INSERT INTO Users (Username, PasswordHash, FullName, Role) 
                                              VALUES ('admin', @hash, 'Administrator', 'Admin')";
                        using (var cmd2 = new SQLiteCommand(insertAdmin, conn))
                        {
                            cmd2.Parameters.AddWithValue("@hash", SecurityHelper.HashPassword("admin123"));
                            cmd2.ExecuteNonQuery();
                        }
                        
                        // Add sample users
                        InsertSampleUser(conn, "manager1", "manager123", "Sokha Chan", "Manager");
                        InsertSampleUser(conn, "cashier1", "cashier123", "Vithy Pov", "Cashier");
                    }
                }
            }
        }

        private void InsertSampleUser(SQLiteConnection conn, string username, string password, string fullName, string role)
        {
            string sql = @"INSERT INTO Users (Username, PasswordHash, FullName, Role) 
                          VALUES (@username, @hash, @fullname, @role)";
            using (var cmd = new SQLiteCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@hash", SecurityHelper.HashPassword(password));
                cmd.Parameters.AddWithValue("@fullname", fullName);
                cmd.Parameters.AddWithValue("@role", role);
                cmd.ExecuteNonQuery();
            }
        }

        public User AuthenticateUser(string username, string password)
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = "SELECT * FROM Users WHERE Username = @username AND IsActive = 1";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string storedHash = reader.GetString(2);
                            if (SecurityHelper.VerifyPassword(password, storedHash))
                            {
                                return new User
                                {
                                    Id = reader.GetInt32(0),
                                    Username = reader.GetString(1),
                                    FullName = reader.GetString(3),
                                    Role = reader.GetString(4),
                                    CreatedDate = reader.GetDateTime(5),
                                    IsActive = reader.GetInt32(6) == 1
                                };
                            }
                        }
                    }
                }
            }
            return null;
        }

        public DataTable GetAllUsers()
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = "SELECT Id, Username, FullName, Role, CreatedDate, IsActive FROM Users ORDER BY Id";
                using (var cmd = new SQLiteCommand(query, conn))
                using (var adapter = new SQLiteDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
            }
        }

        // ========== CUSTOMER MANAGEMENT ==========
        
        public void InitializeCustomersTable()
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                
                string createCustomers = @"CREATE TABLE IF NOT EXISTS Customers (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Name TEXT NOT NULL,
                    Phone TEXT NOT NULL,
                    Email TEXT,
                    Address TEXT,
                    LoyaltyPoints INTEGER DEFAULT 0,
                    CreatedDate DATETIME DEFAULT CURRENT_TIMESTAMP,
                    LastPurchase DATETIME
                )";
                
                using (var cmd = new SQLiteCommand(createCustomers, conn))
                    cmd.ExecuteNonQuery();
                
                // Add sample customers
                string checkCustomers = "SELECT COUNT(*) FROM Customers";
                using (var cmd = new SQLiteCommand(checkCustomers, conn))
                {
                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    if (count == 0)
                    {
                        string[] sampleCustomers = {
                            "INSERT INTO Customers (Name, Phone, Email, Address, LoyaltyPoints) VALUES ('Dara Kim', '012345678', 'dara@email.com', 'Phnom Penh', 150)",
                            "INSERT INTO Customers (Name, Phone, Email, Address, LoyaltyPoints) VALUES ('Sophea Tan', '098765432', 'sophea@email.com', 'Siem Reap', 280)",
                            "INSERT INTO Customers (Name, Phone, Email, Address, LoyaltyPoints) VALUES ('Raksa Chen', '011223344', 'raksa@email.com', 'Battambang', 95)"
                        };
                        
                        foreach (var sql in sampleCustomers)
                        {
                            using (var cmd2 = new SQLiteCommand(sql, conn))
                                cmd2.ExecuteNonQuery();
                        }
                    }
                }
            }
        }

        public DataTable GetAllCustomers()
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = "SELECT Id, Name, Phone, Email, Address, LoyaltyPoints, CreatedDate FROM Customers ORDER BY Name";
                using (var cmd = new SQLiteCommand(query, conn))
                using (var adapter = new SQLiteDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
            }
        }

        public DataTable SearchCustomers(string searchTerm)
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = @"SELECT Id, Name, Phone, Email, Address, LoyaltyPoints, CreatedDate 
                                FROM Customers 
                                WHERE Name LIKE @search OR Phone LIKE @search OR Email LIKE @search
                                ORDER BY Name";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@search", $"%{searchTerm}%");
                    using (var adapter = new SQLiteDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        public Customer GetCustomerById(int id)
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = "SELECT * FROM Customers WHERE Id = @id";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Customer
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Phone = reader.GetString(2),
                                Email = reader.IsDBNull(3) ? "" : reader.GetString(3),
                                Address = reader.IsDBNull(4) ? "" : reader.GetString(4),
                                LoyaltyPoints = reader.GetInt32(5),
                                CreatedDate = reader.GetDateTime(6),
                                LastPurchase = reader.IsDBNull(7) ? (DateTime?)null : reader.GetDateTime(7)
                            };
                        }
                    }
                }
            }
            return null;
        }

        public void AddCustomer(string name, string phone, string email, string address, int loyaltyPoints)
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = @"INSERT INTO Customers (Name, Phone, Email, Address, LoyaltyPoints) 
                                VALUES (@name, @phone, @email, @address, @points)";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@phone", phone);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@address", address);
                    cmd.Parameters.AddWithValue("@points", loyaltyPoints);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void UpdateCustomer(int id, string name, string phone, string email, string address, int loyaltyPoints)
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = @"UPDATE Customers 
                                SET Name = @name, Phone = @phone, Email = @email, 
                                    Address = @address, LoyaltyPoints = @points 
                                WHERE Id = @id";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@phone", phone);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@address", address);
                    cmd.Parameters.AddWithValue("@points", loyaltyPoints);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void DeleteCustomer(int id)
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = "DELETE FROM Customers WHERE Id = @id";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // ========== ACTIVITY LOG ==========
        
        public void InitializeActivityLogTable()
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                
                string createLog = @"CREATE TABLE IF NOT EXISTS ActivityLog (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    UserId INTEGER,
                    Action TEXT NOT NULL,
                    Details TEXT,
                    Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(UserId) REFERENCES Users(Id)
                )";
                
                using (var cmd = new SQLiteCommand(createLog, conn))
                    cmd.ExecuteNonQuery();
            }
        }

        public void LogActivity(int userId, string action, string details)
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = "INSERT INTO ActivityLog (UserId, Action, Details) VALUES (@userId, @action, @details)";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@userId", userId);
                    cmd.Parameters.AddWithValue("@action", action);
                    cmd.Parameters.AddWithValue("@details", details);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public DataTable GetActivityLog(int limit = 50)
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = @"SELECT al.Id, u.FullName as User, al.Action, al.Details, al.Timestamp
                                FROM ActivityLog al
                                JOIN Users u ON al.UserId = u.Id
                                ORDER BY al.Timestamp DESC
                                LIMIT @limit";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@limit", limit);
                    using (var adapter = new SQLiteDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Call this in InitializeDatabase()
        public void InitializeNewTables()
        {
            InitializeUsersTable();
            InitializeCustomersTable();
            InitializeActivityLogTable();
        }
    }
}
