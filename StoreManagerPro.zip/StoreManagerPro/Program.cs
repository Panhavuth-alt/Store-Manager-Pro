namespace PremiumStoreUI;

static class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        
        // Initialize database (includes all tables)
        DatabaseManager.Instance.InitializeDatabase();
        
        // Start with Login Form
        Application.Run(new LoginForm());
    }
}
