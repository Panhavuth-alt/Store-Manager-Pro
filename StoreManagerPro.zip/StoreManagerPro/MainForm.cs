using System.Windows.Forms.DataVisualization.Charting;
using System.Data.SQLite;

namespace PremiumStoreUI
{
    public partial class MainForm : Form
    {
        private Panel sidebarPanel;
        private Panel contentPanel;
        private Panel topBarPanel;
        private Button activeButton = null;

        // Singleton Pattern - Design Pattern #1
        private static MainForm instance;
        public static MainForm Instance
        {
            get
            {
                if (instance == null)
                    instance = new MainForm();
                return instance;
            }
        }

        private MainForm()
        {
            this.Size = new Size(1280, 850);
            this.BackColor = Color.FromArgb(15, 15, 18);
            this.Text = "Store Manager Pro";
            this.StartPosition = FormStartPosition.CenterScreen;
            
            DatabaseManager.Instance.InitializeDatabase();
            InitializeLayout();
            LoadDashboard();
        }

        private void InitializeLayout()
        {
            // Top Bar
            topBarPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                BackColor = Color.FromArgb(20, 20, 23)
            };

            Label titleLabel = new Label
            {
                Text = "Store Manager Pro",
                Location = new Point(20, 18),
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true
            };

            Label dateLabel = new Label
            {
                Text = DateTime.Now.ToString("dddd, MMMM dd, yyyy"),
                Location = new Point(650, 18),
                Font = new Font("Segoe UI", 11),
                ForeColor = Color.Gray,
                AutoSize = true
            };

            Label timeLabel = new Label
            {
                Text = DateTime.Now.ToString("hh:mm:ss tt"),
                Location = new Point(1100, 18),
                Font = new Font("Segoe UI", 11),
                ForeColor = Color.White,
                AutoSize = true
            };

            topBarPanel.Controls.AddRange(new Control[] { titleLabel, dateLabel, timeLabel });

            // Fix: Use fully qualified name for Timer
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer { Interval = 1000 };
            timer.Tick += (s, e) => timeLabel.Text = DateTime.Now.ToString("hh:mm:ss tt");
            timer.Start();

            // Sidebar
            sidebarPanel = new Panel
            {
                Dock = DockStyle.Left,
                Width = 180,
                BackColor = Color.FromArgb(28, 28, 30)
            };

            string[] navItems = { "Dashboard", "Inventory", "Customers", "POS Terminal", "Reports" };
            string[] icons = { "📊", "📦", "👥", "💳", "📈" };
            
            for (int i = 0; i < navItems.Length; i++)
            {
                Button btn = CreateNavButton(navItems[i], icons[i], i);
                sidebarPanel.Controls.Add(btn);
            }

            contentPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(15, 15, 18),
                Padding = new Padding(30),
                AutoScroll = true
            };

            this.Controls.Add(contentPanel);
            this.Controls.Add(sidebarPanel);
            this.Controls.Add(topBarPanel);
        }

        private Button CreateNavButton(string text, string icon, int index)
        {
            Button btn = new Button
            {
                Text = $"{icon}  {text}",
                Location = new Point(0, 70 + (index * 70)),
                Width = 180,
                Height = 60,
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.Gray,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font("Segoe UI", 11),
                Padding = new Padding(20, 0, 0, 0),
                BackColor = Color.FromArgb(28, 28, 30)
            };

            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(40, 40, 45);

            btn.Click += (s, e) =>
            {
                SetActiveButton(btn);
                switch (text)
                {
                    case "Dashboard": LoadDashboard(); break;
                    case "Inventory": LoadInventory(); break;
                    case "Customers": LoadCustomers(); break;
                    case "POS Terminal": LoadPOS(); break;
                    case "Reports": LoadReports(); break;
                }
            };

            return btn;
        }

        private void SetActiveButton(Button btn)
        {
            if (activeButton != null)
            {
                activeButton.ForeColor = Color.Gray;
                activeButton.BackColor = Color.FromArgb(28, 28, 30);
            }

            activeButton = btn;
            btn.ForeColor = Color.White;
            btn.BackColor = Color.FromArgb(45, 45, 50);
        }

        private void LoadDashboard()
        {
            contentPanel.Controls.Clear();

            Label title = new Label
            {
                Text = "Dashboard",
                Location = new Point(0, 10),
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true
            };
            contentPanel.Controls.Add(title);

            // Factory Pattern - Design Pattern #2
            CardFactory factory = new CardFactory();
            
            var stats = DatabaseManager.Instance.GetDashboardStats();
            
            var salesCard = factory.CreateCard("Total Sales", $"${stats.TotalSales:F2}", Color.FromArgb(80, 70, 150), new Point(0, 80));
            var lowStockCard = factory.CreateCard("Low Stock Items", stats.LowStock.ToString(), Color.FromArgb(150, 60, 60), new Point(240, 80));
            var ordersCard = factory.CreateCard("Total Orders", stats.TotalOrders.ToString(), Color.FromArgb(60, 110, 150), new Point(480, 80));
            var revenueCard = factory.CreateCard("Revenue", $"${stats.Revenue:F2}", Color.FromArgb(60, 130, 100), new Point(720, 80));

            contentPanel.Controls.AddRange(new Control[] { salesCard, lowStockCard, ordersCard, revenueCard });

            CreateSalesChart();
        }

        private void CreateSalesChart()
        {
            Chart chart = new Chart
            {
                Location = new Point(0, 260),
                Size = new Size(980, 420),
                BackColor = Color.FromArgb(25, 25, 30),
                BorderlineColor = Color.FromArgb(50, 50, 55),
                BorderlineWidth = 1
            };

            ChartArea chartArea = new ChartArea
            {
                BackColor = Color.FromArgb(25, 25, 30),
                BorderWidth = 0
            };
            chartArea.AxisX.MajorGrid.LineColor = Color.FromArgb(40, 40, 45);
            chartArea.AxisY.MajorGrid.LineColor = Color.FromArgb(40, 40, 45);
            chartArea.AxisX.LabelStyle.ForeColor = Color.Gray;
            chartArea.AxisY.LabelStyle.ForeColor = Color.Gray;
            chartArea.AxisX.LineColor = Color.FromArgb(60, 60, 65);
            chartArea.AxisY.LineColor = Color.FromArgb(60, 60, 65);
            chart.ChartAreas.Add(chartArea);

            Series series = new Series
            {
                ChartType = SeriesChartType.Column,
                Color = Color.FromArgb(100, 150, 255),
                BackGradientStyle = GradientStyle.TopBottom,
                BackSecondaryColor = Color.FromArgb(150, 100, 255)
            };

            var salesData = DatabaseManager.Instance.GetWeeklySales();
            for (int i = 0; i < salesData.Length; i++)
            {
                series.Points.AddXY($"{i + 1} Days", salesData[i]);
            }

            chart.Series.Add(series);

            Title chartTitle = new Title
            {
                Text = "Sales trend over the last 7 days",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                Alignment = ContentAlignment.TopLeft,
                Docking = Docking.Top
            };
            chart.Titles.Add(chartTitle);

            contentPanel.Controls.Add(chart);
        }

        private void LoadInventory()
        {
            contentPanel.Controls.Clear();

            Label title = new Label
            {
                Text = "Inventory",
                Location = new Point(0, 10),
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true
            };
            contentPanel.Controls.Add(title);

            TextBox searchBox = new TextBox
            {
                Location = new Point(0, 70),
                Width = 300,
                Height = 35,
                Font = new Font("Segoe UI", 12),
                BackColor = Color.FromArgb(35, 35, 40),
                ForeColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            searchBox.Text = "🔍 Search products...";
            searchBox.ForeColor = Color.Gray;

            searchBox.GotFocus += (s, e) =>
            {
                if (searchBox.Text == "🔍 Search products...")
                {
                    searchBox.Text = "";
                    searchBox.ForeColor = Color.White;
                }
            };

            searchBox.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(searchBox.Text))
                {
                    searchBox.Text = "🔍 Search products...";
                    searchBox.ForeColor = Color.Gray;
                }
            };

            contentPanel.Controls.Add(searchBox);

            Button addBtn = CreateActionButton("➕ Add Product", new Point(320, 70));
            Button editBtn = CreateActionButton("✏️ Edit", new Point(480, 70));
            Button deleteBtn = CreateActionButton("🗑️ Delete", new Point(600, 70));

            contentPanel.Controls.AddRange(new Control[] { addBtn, editBtn, deleteBtn });

            DataGridView dgv = new DataGridView
            {
                Location = new Point(0, 130),
                Size = new Size(980, 520),
                BackgroundColor = Color.FromArgb(25, 25, 30),
                BorderStyle = BorderStyle.None,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(35, 35, 40),
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 11, FontStyle.Bold),
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                    Padding = new Padding(8, 5, 8, 5)
                },
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(25, 25, 30),
                    ForeColor = Color.White,
                    SelectionBackColor = Color.FromArgb(60, 70, 130),
                    SelectionForeColor = Color.White,
                    Font = new Font("Segoe UI", 10),
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                    Padding = new Padding(8, 0, 8, 0)
                },
                EnableHeadersVisualStyles = false,
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ColumnHeadersHeight = 40
            };

            dgv.RowTemplate.Height = 35;

            var products = DatabaseManager.Instance.GetAllProducts();
            dgv.DataSource = products;

            contentPanel.Controls.Add(dgv);

            // Observer Pattern - Design Pattern #3
            searchBox.TextChanged += (s, e) =>
            {
                if (searchBox.Text != "🔍 Search products..." && !string.IsNullOrWhiteSpace(searchBox.Text))
                {
                    var filtered = DatabaseManager.Instance.SearchProducts(searchBox.Text);
                    dgv.DataSource = filtered;
                }
                else
                {
                    dgv.DataSource = DatabaseManager.Instance.GetAllProducts();
                }
            };

            addBtn.Click += (s, e) => { ShowProductDialog(); LoadInventory(); };
            editBtn.Click += (s, e) =>
            {
                if (dgv.SelectedRows.Count > 0)
                {
                    int id = Convert.ToInt32(dgv.SelectedRows[0].Cells["Id"].Value);
                    ShowProductDialog(id);
                    LoadInventory();
                }
            };
            deleteBtn.Click += (s, e) =>
            {
                if (dgv.SelectedRows.Count > 0)
                {
                    int id = Convert.ToInt32(dgv.SelectedRows[0].Cells["Id"].Value);
                    if (MessageBox.Show("Delete this product?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        DatabaseManager.Instance.DeleteProduct(id);
                        LoadInventory();
                    }
                }
            };
        }

        private void ShowProductDialog(int? productId = null)
        {
            Form dialog = new Form
            {
                Size = new Size(450, 400),
                BackColor = Color.FromArgb(25, 25, 30),
                FormBorderStyle = FormBorderStyle.FixedDialog,
                StartPosition = FormStartPosition.CenterParent,
                Text = productId.HasValue ? "Edit Product" : "Add Product",
                MaximizeBox = false,
                MinimizeBox = false
            };

            Label lblName = new Label { Text = "Product Name:", Location = new Point(30, 30), ForeColor = Color.White, AutoSize = true };
            TextBox txtName = new TextBox { Location = new Point(30, 55), Width = 380, BackColor = Color.FromArgb(35, 35, 40), ForeColor = Color.White };

            Label lblPrice = new Label { Text = "Price:", Location = new Point(30, 100), ForeColor = Color.White, AutoSize = true };
            TextBox txtPrice = new TextBox { Location = new Point(30, 125), Width = 380, BackColor = Color.FromArgb(35, 35, 40), ForeColor = Color.White };

            Label lblStock = new Label { Text = "Stock:", Location = new Point(30, 170), ForeColor = Color.White, AutoSize = true };
            TextBox txtStock = new TextBox { Location = new Point(30, 195), Width = 380, BackColor = Color.FromArgb(35, 35, 40), ForeColor = Color.White };

            Label lblCategory = new Label { Text = "Category:", Location = new Point(30, 240), ForeColor = Color.White, AutoSize = true };
            TextBox txtCategory = new TextBox { Location = new Point(30, 265), Width = 380, BackColor = Color.FromArgb(35, 35, 40), ForeColor = Color.White };

            Button btnSave = new Button
            {
                Text = "Save",
                Location = new Point(230, 310),
                Width = 80,
                BackColor = Color.FromArgb(60, 120, 100),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };

            Button btnCancel = new Button
            {
                Text = "Cancel",
                Location = new Point(320, 310),
                Width = 80,
                BackColor = Color.FromArgb(100, 50, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };

            if (productId.HasValue)
            {
                var product = DatabaseManager.Instance.GetProductById(productId.Value);
                txtName.Text = product.Name;
                txtPrice.Text = product.Price.ToString();
                txtStock.Text = product.Stock.ToString();
                txtCategory.Text = product.Category;
            }

            btnSave.Click += (s, e) =>
            {
                if (productId.HasValue)
                {
                    DatabaseManager.Instance.UpdateProduct(productId.Value, txtName.Text, decimal.Parse(txtPrice.Text), int.Parse(txtStock.Text), txtCategory.Text);
                }
                else
                {
                    DatabaseManager.Instance.AddProduct(txtName.Text, decimal.Parse(txtPrice.Text), int.Parse(txtStock.Text), txtCategory.Text);
                }
                dialog.Close();
            };

            btnCancel.Click += (s, e) => dialog.Close();

            dialog.Controls.AddRange(new Control[] { lblName, txtName, lblPrice, txtPrice, lblStock, txtStock, lblCategory, txtCategory, btnSave, btnCancel });
            dialog.ShowDialog();
        }

        private void LoadPOS()
        {
            contentPanel.Controls.Clear();

            Label title = new Label
            {
                Text = "POS Terminal",
                Location = new Point(0, 10),
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true
            };
            contentPanel.Controls.Add(title);

            // Strategy Pattern - Design Pattern #4
            POSTerminal posTerminal = new POSTerminal(contentPanel);
            posTerminal.Initialize();
        }

        private void LoadReports()
        {
            contentPanel.Controls.Clear();

            Label title = new Label
            {
                Text = "Reports",
                Location = new Point(0, 10),
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true
            };
            contentPanel.Controls.Add(title);

            // Command Pattern - Design Pattern #5
            ReportGenerator reportGen = new ReportGenerator(contentPanel);
            reportGen.GenerateReports();
        }

        private void LoadCustomers()
        {
            // Check permission
            var user = CurrentUser.Instance.GetUser();
            if (user != null && !user.CanManageCustomers())
            {
                contentPanel.Controls.Clear();
                Label accessDenied = new Label
                {
                    Text = "🚫 Access Denied\n\nYou don't have permission to manage customers.",
                    Location = new Point(200, 200),
                    Size = new Size(600, 100),
                    Font = new Font("Segoe UI", 16),
                    ForeColor = Color.FromArgb(255, 100, 100),
                    TextAlign = ContentAlignment.MiddleCenter
                };
                contentPanel.Controls.Add(accessDenied);
                return;
            }

            CustomerManagementUI customerUI = new CustomerManagementUI(contentPanel);
            customerUI.Initialize();
        }

        private Button CreateActionButton(string text, Point location)
        {
            Button btn = new Button
            {
                Text = text,
                Location = location,
                Width = 140,
                Height = 40,
                BackColor = Color.FromArgb(60, 70, 130),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10)
            };
            btn.FlatAppearance.BorderSize = 0;
            return btn;
        }
    }
}
