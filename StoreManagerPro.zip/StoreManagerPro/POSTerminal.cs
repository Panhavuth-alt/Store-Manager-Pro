using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace PremiumStoreUI
{
    // Strategy Pattern - Design Pattern #4
    public interface IPaymentStrategy
    {
        bool ProcessPayment(decimal amount);
        string GetPaymentMethodName();
    }

    public class CashPayment : IPaymentStrategy
    {
        public bool ProcessPayment(decimal amount)
        {
            MessageBox.Show($"Cash payment of ${amount:F2} received successfully!", "Payment Successful");
            return true;
        }

        public string GetPaymentMethodName() => "Cash";
    }

    public class CardPayment : IPaymentStrategy
    {
        public bool ProcessPayment(decimal amount)
        {
            MessageBox.Show($"Card payment of ${amount:F2} processed successfully!", "Payment Successful");
            return true;
        }

        public string GetPaymentMethodName() => "Credit/Debit Card";
    }

    public class MobilePayment : IPaymentStrategy
    {
        public bool ProcessPayment(decimal amount)
        {
            MessageBox.Show($"Mobile payment of ${amount:F2} completed successfully!", "Payment Successful");
            return true;
        }

        public string GetPaymentMethodName() => "Mobile Wallet";
    }

    public class POSTerminal
    {
        private Panel panel;
        private ListBox cartListBox;
        private Label totalLabel;
        private ComboBox productCombo;
        private NumericUpDown quantityInput;
        private List<CartItem> cart = new List<CartItem>();
        private IPaymentStrategy paymentStrategy;

        public POSTerminal(Panel contentPanel)
        {
            this.panel = contentPanel;
        }

        public void Initialize()
        {
            // Left side - Product selection
            Panel leftPanel = new Panel
            {
                Location = new Point(0, 70),
                Size = new Size(480, 600),
                BackColor = Color.FromArgb(25, 25, 30)
            };

            Label lblProduct = new Label
            {
                Text = "Select Product:",
                Location = new Point(20, 20),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12),
                AutoSize = true
            };

            productCombo = new ComboBox
            {
                Location = new Point(20, 50),
                Width = 440,
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.FromArgb(35, 35, 40),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11)
            };

            LoadProducts();

            Label lblQuantity = new Label
            {
                Text = "Quantity:",
                Location = new Point(20, 100),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12),
                AutoSize = true
            };

            quantityInput = new NumericUpDown
            {
                Location = new Point(20, 130),
                Width = 150,
                Minimum = 1,
                Maximum = 100,
                Value = 1,
                BackColor = Color.FromArgb(35, 35, 40),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11)
            };

            Button addToCartBtn = new Button
            {
                Text = "➕ Add to Cart",
                Location = new Point(190, 130),
                Width = 150,
                Height = 35,
                BackColor = Color.FromArgb(60, 120, 100),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11)
            };
            addToCartBtn.FlatAppearance.BorderSize = 0;
            addToCartBtn.Click += AddToCart;

            Label lblCart = new Label
            {
                Text = "Shopping Cart:",
                Location = new Point(20, 190),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                AutoSize = true
            };

            cartListBox = new ListBox
            {
                Location = new Point(20, 220),
                Size = new Size(440, 300),
                BackColor = Color.FromArgb(30, 30, 35),
                ForeColor = Color.White,
                BorderStyle = BorderStyle.None,
                Font = new Font("Segoe UI", 10)
            };

            Button removeBtn = new Button
            {
                Text = "🗑️ Remove Selected",
                Location = new Point(20, 535),
                Width = 150,
                Height = 35,
                BackColor = Color.FromArgb(150, 60, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10)
            };
            removeBtn.FlatAppearance.BorderSize = 0;
            removeBtn.Click += RemoveFromCart;

            leftPanel.Controls.AddRange(new Control[] { lblProduct, productCombo, lblQuantity, quantityInput, addToCartBtn, lblCart, cartListBox, removeBtn });

            // Right side - Payment
            Panel rightPanel = new Panel
            {
                Location = new Point(500, 70),
                Size = new Size(480, 600),
                BackColor = Color.FromArgb(25, 25, 30)
            };

            Label lblTotal = new Label
            {
                Text = "Total Amount:",
                Location = new Point(20, 20),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                AutoSize = true
            };

            totalLabel = new Label
            {
                Text = "$0.00",
                Location = new Point(20, 60),
                ForeColor = Color.FromArgb(100, 200, 100),
                Font = new Font("Segoe UI", 32, FontStyle.Bold),
                AutoSize = true
            };

            Label lblPayment = new Label
            {
                Text = "Payment Method:",
                Location = new Point(20, 140),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                AutoSize = true
            };

            // Fix: Declare all buttons first before using them in click events
            Button cashBtn = new Button
            {
                Text = "💵 Cash",
                Location = new Point(20, 180),
                Size = new Size(140, 80),
                BackColor = Color.FromArgb(60, 100, 140),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 14)
            };
            cashBtn.FlatAppearance.BorderSize = 0;

            Button cardBtn = new Button
            {
                Text = "💳 Card",
                Location = new Point(170, 180),
                Size = new Size(140, 80),
                BackColor = Color.FromArgb(60, 100, 140),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 14)
            };
            cardBtn.FlatAppearance.BorderSize = 0;

            Button mobileBtn = new Button
            {
                Text = "📱 Mobile",
                Location = new Point(320, 180),
                Size = new Size(140, 80),
                BackColor = Color.FromArgb(60, 100, 140),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 14)
            };
            mobileBtn.FlatAppearance.BorderSize = 0;

            // Now attach click events after all buttons are declared
            cashBtn.Click += (s, e) => { paymentStrategy = new CashPayment(); HighlightButton(cashBtn, new[] { cashBtn, cardBtn, mobileBtn }); };
            cardBtn.Click += (s, e) => { paymentStrategy = new CardPayment(); HighlightButton(cardBtn, new[] { cashBtn, cardBtn, mobileBtn }); };
            mobileBtn.Click += (s, e) => { paymentStrategy = new MobilePayment(); HighlightButton(mobileBtn, new[] { cashBtn, cardBtn, mobileBtn }); };

            Button checkoutBtn = new Button
            {
                Text = "✓ Complete Purchase",
                Location = new Point(20, 300),
                Size = new Size(440, 60),
                BackColor = Color.FromArgb(60, 140, 100),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 16, FontStyle.Bold)
            };
            checkoutBtn.FlatAppearance.BorderSize = 0;
            checkoutBtn.Click += CompletePurchase;

            Button clearBtn = new Button
            {
                Text = "Clear Cart",
                Location = new Point(20, 380),
                Width = 200,
                Height = 45,
                BackColor = Color.FromArgb(100, 50, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 12)
            };
            clearBtn.FlatAppearance.BorderSize = 0;
            clearBtn.Click += (s, e) => { cart.Clear(); UpdateCart(); };

            rightPanel.Controls.AddRange(new Control[] { lblTotal, totalLabel, lblPayment, cashBtn, cardBtn, mobileBtn, checkoutBtn, clearBtn });

            panel.Controls.AddRange(new Control[] { leftPanel, rightPanel });
        }

        private void LoadProducts()
        {
            var products = DatabaseManager.Instance.GetAllProducts();
            productCombo.Items.Clear();
            foreach (DataRow row in products.Rows)
            {
                productCombo.Items.Add(new ProductItem
                {
                    Id = Convert.ToInt32(row["Id"]),
                    Name = row["Name"].ToString(),
                    Price = Convert.ToDecimal(row["Price"]),
                    Stock = Convert.ToInt32(row["Stock"])
                });
            }
            if (productCombo.Items.Count > 0)
                productCombo.SelectedIndex = 0;
        }

        private void AddToCart(object sender, EventArgs e)
        {
            if (productCombo.SelectedItem == null) return;

            var product = (ProductItem)productCombo.SelectedItem;
            int quantity = (int)quantityInput.Value;

            if (quantity > product.Stock)
            {
                MessageBox.Show($"Insufficient stock! Available: {product.Stock}", "Error");
                return;
            }

            cart.Add(new CartItem
            {
                ProductId = product.Id,
                ProductName = product.Name,
                Price = product.Price,
                Quantity = quantity
            });

            UpdateCart();
        }

        private void RemoveFromCart(object sender, EventArgs e)
        {
            if (cartListBox.SelectedIndex >= 0)
            {
                cart.RemoveAt(cartListBox.SelectedIndex);
                UpdateCart();
            }
        }

        private void UpdateCart()
        {
            cartListBox.Items.Clear();
            decimal total = 0;

            foreach (var item in cart)
            {
                cartListBox.Items.Add($"{item.ProductName} x{item.Quantity} - ${item.Price * item.Quantity:F2}");
                total += item.Price * item.Quantity;
            }

            totalLabel.Text = $"${total:F2}";
        }

        private void CompletePurchase(object sender, EventArgs e)
        {
            if (cart.Count == 0)
            {
                MessageBox.Show("Cart is empty!", "Error");
                return;
            }

            if (paymentStrategy == null)
            {
                MessageBox.Show("Please select a payment method!", "Error");
                return;
            }

            decimal total = cart.Sum(item => item.Price * item.Quantity);

            if (paymentStrategy.ProcessPayment(total))
            {
                foreach (var item in cart)
                {
                    DatabaseManager.Instance.AddSale(item.ProductId, item.Quantity, item.Price * item.Quantity);
                }

                cart.Clear();
                UpdateCart();
                LoadProducts(); // Refresh stock
            }
        }

        private void HighlightButton(Button selected, Button[] all)
        {
            foreach (var btn in all)
            {
                btn.BackColor = Color.FromArgb(60, 100, 140);
            }
            selected.BackColor = Color.FromArgb(80, 140, 180);
        }
    }

    public class ProductItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int Stock { get; set; }

        public override string ToString()
        {
            return $"{Name} - ${Price:F2} (Stock: {Stock})";
        }
    }

    public class CartItem
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
    }
}
