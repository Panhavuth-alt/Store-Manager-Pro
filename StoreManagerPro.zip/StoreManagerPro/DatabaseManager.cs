using System.Data;
using System.Data.SQLite;

namespace PremiumStoreUI
{
    // Singleton Pattern - Design Pattern #1
    public partial class DatabaseManager
    {
        private static DatabaseManager instance;
        private string dbPath = "store.db";

        public static DatabaseManager Instance
        {
            get
            {
                if (instance == null)
                    instance = new DatabaseManager();
                return instance;
            }
        }

        private DatabaseManager() { }

        public void InitializeDatabase()
        {
            if (!File.Exists(dbPath))
            {
                SQLiteConnection.CreateFile(dbPath);
                using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
                {
                    conn.Open();
                    
                    string createProducts = @"CREATE TABLE Products (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Name TEXT NOT NULL,
                        Price REAL NOT NULL,
                        Stock INTEGER NOT NULL,
                        Category TEXT
                    )";
                    
                    string createSales = @"CREATE TABLE Sales (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        ProductId INTEGER,
                        Quantity INTEGER,
                        TotalAmount REAL,
                        SaleDate DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY(ProductId) REFERENCES Products(Id)
                    )";
                    
                    using (var cmd = new SQLiteCommand(createProducts, conn))
                        cmd.ExecuteNonQuery();
                    
                    using (var cmd = new SQLiteCommand(createSales, conn))
                        cmd.ExecuteNonQuery();
                    
                    // Sample data
                    string[] sampleProducts = {
                        "INSERT INTO Products (Name, Price, Stock, Category) VALUES ('Laptop HP', 899.99, 15, 'Electronics')",
                        "INSERT INTO Products (Name, Price, Stock, Category) VALUES ('Mouse Logitech', 24.99, 50, 'Accessories')",
                        "INSERT INTO Products (Name, Price, Stock, Category) VALUES ('Keyboard Mechanical', 79.99, 30, 'Accessories')",
                        "INSERT INTO Products (Name, Price, Stock, Category) VALUES ('Monitor Dell 24 inch', 299.99, 8, 'Electronics')",
                        "INSERT INTO Products (Name, Price, Stock, Category) VALUES ('USB Cable', 9.99, 2, 'Accessories')",
                        "INSERT INTO Products (Name, Price, Stock, Category) VALUES ('Headphones Sony', 149.99, 20, 'Electronics')",
                        "INSERT INTO Products (Name, Price, Stock, Category) VALUES ('Webcam HD', 59.99, 12, 'Electronics')"
                    };
                    
                    foreach (var sql in sampleProducts)
                    {
                        using (var cmd = new SQLiteCommand(sql, conn))
                            cmd.ExecuteNonQuery();
                    }
                    
                    // Sample sales for chart
                    Random rand = new Random();
                    for (int day = 1; day <= 7; day++)
                    {
                        int numSales = rand.Next(2, 6);
                        for (int i = 0; i < numSales; i++)
                        {
                            int productId = rand.Next(1, 8);
                            int quantity = rand.Next(1, 4);
                            decimal amount = (decimal)(rand.Next(50, 500));
                            
                            string insertSale = $"INSERT INTO Sales (ProductId, Quantity, TotalAmount, SaleDate) VALUES ({productId}, {quantity}, {amount}, datetime('now', '-{8-day} days'))";
                            using (var cmd = new SQLiteCommand(insertSale, conn))
                                cmd.ExecuteNonQuery();
                        }
                    }
                }
            }
            
            // Initialize new tables (Users, Customers, ActivityLog)
            InitializeNewTables();
        }

        public DashboardStats GetDashboardStats()
        {
            var stats = new DashboardStats();
            
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                
                string salesQuery = "SELECT COALESCE(SUM(TotalAmount), 0) FROM Sales";
                using (var cmd = new SQLiteCommand(salesQuery, conn))
                {
                    stats.TotalSales = Convert.ToDecimal(cmd.ExecuteScalar());
                }
                
                string stockQuery = "SELECT COUNT(*) FROM Products WHERE Stock <= 5";
                using (var cmd = new SQLiteCommand(stockQuery, conn))
                {
                    stats.LowStock = Convert.ToInt32(cmd.ExecuteScalar());
                }
                
                string ordersQuery = "SELECT COUNT(*) FROM Sales";
                using (var cmd = new SQLiteCommand(ordersQuery, conn))
                {
                    stats.TotalOrders = Convert.ToInt32(cmd.ExecuteScalar());
                }
                
                stats.Revenue = stats.TotalSales * 0.6m; // 60% profit margin
            }
            
            return stats;
        }

        public decimal[] GetWeeklySales()
        {
            decimal[] sales = new decimal[7];
            
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                
                for (int i = 0; i < 7; i++)
                {
                    string query = $@"SELECT COALESCE(SUM(TotalAmount), 0) 
                                     FROM Sales 
                                     WHERE date(SaleDate) = date('now', '-{6-i} days')";
                    using (var cmd = new SQLiteCommand(query, conn))
                    {
                        sales[i] = Convert.ToDecimal(cmd.ExecuteScalar());
                    }
                }
            }
            
            return sales;
        }

        public DataTable GetAllProducts()
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = "SELECT Id, Name, Price, Stock, Category FROM Products";
                using (var cmd = new SQLiteCommand(query, conn))
                using (var adapter = new SQLiteDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
            }
        }

        public DataTable SearchProducts(string searchTerm)
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = "SELECT Id, Name, Price, Stock, Category FROM Products WHERE Name LIKE @search OR Category LIKE @search";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@search", $"%{searchTerm}%");
                    using (var adapter = new SQLiteDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        public Product GetProductById(int id)
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = "SELECT * FROM Products WHERE Id = @id";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Product
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Price = reader.GetDecimal(2),
                                Stock = reader.GetInt32(3),
                                Category = reader.GetString(4)
                            };
                        }
                    }
                }
            }
            return null;
        }

        public void AddProduct(string name, decimal price, int stock, string category)
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = "INSERT INTO Products (Name, Price, Stock, Category) VALUES (@name, @price, @stock, @category)";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@stock", stock);
                    cmd.Parameters.AddWithValue("@category", category);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void UpdateProduct(int id, string name, decimal price, int stock, string category)
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = "UPDATE Products SET Name = @name, Price = @price, Stock = @stock, Category = @category WHERE Id = @id";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@stock", stock);
                    cmd.Parameters.AddWithValue("@category", category);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void DeleteProduct(int id)
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = "DELETE FROM Products WHERE Id = @id";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void AddSale(int productId, int quantity, decimal totalAmount)
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = "INSERT INTO Sales (ProductId, Quantity, TotalAmount) VALUES (@productId, @quantity, @total)";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@productId", productId);
                    cmd.Parameters.AddWithValue("@quantity", quantity);
                    cmd.Parameters.AddWithValue("@total", totalAmount);
                    cmd.ExecuteNonQuery();
                }
                
                // Update stock
                string updateStock = "UPDATE Products SET Stock = Stock - @quantity WHERE Id = @productId";
                using (var cmd = new SQLiteCommand(updateStock, conn))
                {
                    cmd.Parameters.AddWithValue("@quantity", quantity);
                    cmd.Parameters.AddWithValue("@productId", productId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public DataTable GetSalesReport()
        {
            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = @"SELECT s.Id, p.Name as ProductName, s.Quantity, s.TotalAmount, 
                                strftime('%Y-%m-%d %H:%M', s.SaleDate) as SaleDate
                                FROM Sales s
                                JOIN Products p ON s.ProductId = p.Id
                                ORDER BY s.SaleDate DESC LIMIT 50";
                using (var cmd = new SQLiteCommand(query, conn))
                using (var adapter = new SQLiteDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
            }
        }
    }

    public class DashboardStats
    {
        public decimal TotalSales { get; set; }
        public int LowStock { get; set; }
        public int TotalOrders { get; set; }
        public decimal Revenue { get; set; }
    }

    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int Stock { get; set; }
        public string Category { get; set; }
    }
}
